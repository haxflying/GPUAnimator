﻿namespace Sirenix.Serialization.Formatters
{
	using Sirenix.Utilities;
	using System;
	using System.Collections.Generic;

	[CustomGenericFormatter(typeof(DoubleLookupDictionary<,,>))]
	public sealed class DoubleLookupDictionaryFormatter<TPrimary, TSecondary, TValue> : BaseFormatter<DoubleLookupDictionary<TPrimary, TSecondary, TValue>>
	{
		private static readonly Serializer<TPrimary> PrimaryReaderWriter = Serializer.Get<TPrimary>();
		private static readonly Serializer<Dictionary<TSecondary, TValue>> InnerReaderWriter = Serializer.Get<Dictionary<TSecondary, TValue>>();

		static DoubleLookupDictionaryFormatter()
		{
			new DoubleLookupDictionaryFormatter<int, int, string>();
		}

		public DoubleLookupDictionaryFormatter()
		{

		}

		protected override DoubleLookupDictionary<TPrimary, TSecondary, TValue> GetUninitializedObject()
		{
			return null;
		}

		/// <summary>
		/// Not yet documented.
		/// </summary>
		protected override void SerializeImplementation(ref DoubleLookupDictionary<TPrimary, TSecondary, TValue> value, IDataWriter writer)
		{
			try
			{
				writer.BeginArrayNode(value.Count);

				foreach (var pair in value)
				{
					try
					{
						writer.BeginStructNode(null, null);
						PrimaryReaderWriter.WriteValue(pair.Key, writer);
						InnerReaderWriter.WriteValue(pair.Value, writer);
					}
					catch (Exception ex)
					{
						writer.Context.Config.DebugContext.LogException(ex);
					}
					finally
					{
						writer.EndNode(null);
					}
				}
			}
			finally
			{
				writer.EndArrayNode();
			}
		}

		/// <summary>
		/// Not yet documented.
		/// </summary>
		protected override void DeserializeImplementation(ref DoubleLookupDictionary<TPrimary, TSecondary, TValue> value, IDataReader reader)
		{
			string name;
			var entry = reader.PeekEntry(out name);

			if (entry == EntryType.StartOfArray)
			{
				try
				{
					long length;
					reader.EnterArray(out length);
					Type type;
					value = new DoubleLookupDictionary<TPrimary, TSecondary, TValue>();

					this.RegisterReferenceID(value, reader);

					for (int i = 0; i < length; i++)
					{
						if (reader.PeekEntry(out name) == EntryType.EndOfArray)
						{
							reader.Context.Config.DebugContext.LogError("Reached end of array after " + i + " elements, when " + length + " elements were expected.");
							break;
						}

						try
						{
							reader.EnterNode(out type);
							TPrimary key = PrimaryReaderWriter.ReadValue(reader);
							Dictionary<TSecondary, TValue> inner = InnerReaderWriter.ReadValue(reader);

							value.Add(key, inner);
						}
						catch (Exception ex)
						{
							reader.Context.Config.DebugContext.LogException(ex);
						}
						finally
						{
							reader.ExitNode();
						}

						if (reader.IsInArrayNode == false)
						{
							reader.Context.Config.DebugContext.LogError("Reading array went wrong at position " + reader.Stream.Position + ".");
							break;
						}
					}
				}
				finally
				{
					reader.ExitArray();
				}
			}
			else
			{
				reader.SkipEntry();
			}
		}
	}
}