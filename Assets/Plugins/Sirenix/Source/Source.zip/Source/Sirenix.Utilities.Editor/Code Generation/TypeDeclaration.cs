#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="TypeDeclaration.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Utilities.Editor.CodeGeneration
{
    /// <summary>
    /// Not yet documented.
    /// </summary>
    public enum TypeDeclaration
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        Class = 0,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        StaticClass = 1,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        SealedClass = 2,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Struct = 3
    }
}
#endif